#!/usr/bin/perl

use IO::Socket;
$| = 1;

print "Port numarası giriniz...\n";
my $port=<STDIN>;
#my $user1 = ' Hakan : ';

$socket = new IO::Socket::INET (
    LocalHost => '127.0.0.1',
    LocalPort => $port,
    Proto => 'tcp',
    Listen => 5,
    
);
die "Port açılamadı!" unless $socket;
print "Bağlantı bekleniyor...Port : $port\n ";

while(1)
{
        $client_socket = "";
        $client_socket = $socket->accept();
        $peer_address = $client_socket->peerhost();
        $peer_port = $client_socket->peerport();

        print "\n CTRL Chat Server'a  Bağlantı Kuruldu. ( $peer_address , $peer_port ) \n";

        while (1){
		my $user1 = " Hakan : ";
		$client_socket->recv($gelen_veri,30);
		print "\n Kullanici :  ". $gelen_veri ;
		$giden_veri = $gelen_veri * $gelen_veri;
                $client_socket->send($user1);
                $client_socket->send($giden_veri);
                $client_socket->autoflush();
        }
}








