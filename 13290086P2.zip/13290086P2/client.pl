#!/usr/bin/perl

use IO::Socket;

print "Port numarası giriniz...\n";
my $port=<STDIN>;


$socket = new IO::Socket::INET (
    PeerAddr  => '127.0.0.1',
    PeerPort  =>  $port,
    Proto => 'tcp',
)
or die "Bağlantı Kurulamadı !\n";

while (1) {
        
        $giden_veri = <STDIN> + 0;
        my $user2 = "Kullanici : ";
#        $socket->send($user2);
        $socket->send($giden_veri);
	$socket->recv($gelen_veri,30);
        print $gelen_veri."\n";

}









